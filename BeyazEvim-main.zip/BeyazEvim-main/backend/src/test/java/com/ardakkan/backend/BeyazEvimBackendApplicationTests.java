package com.ardakkan.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeyazEvimBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
