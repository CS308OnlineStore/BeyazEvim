package com.ardakkan.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeyazEvimBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeyazEvimBackendApplication.class, args);
	}

}
