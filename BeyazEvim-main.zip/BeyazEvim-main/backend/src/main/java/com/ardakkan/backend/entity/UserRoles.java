package com.ardakkan.backend.entity;

public enum UserRoles {
    CUSTOMER, SALES_MANAGER, PRODUCT_OWNER
}

